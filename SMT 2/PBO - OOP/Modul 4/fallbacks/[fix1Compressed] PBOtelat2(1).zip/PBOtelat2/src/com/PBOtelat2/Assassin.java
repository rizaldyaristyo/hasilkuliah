package com.PBOtelat2;

public class Assassin extends Character implements CriticalDamage{

    public Assassin(int level,String playerN){
        this.level = level;
        checkStatus(playerN,2500,200,750,true,this.level);
    }
    @Override
    public void spawnIntro(){
        System.out.println("'Bergerak seperti angin yang apalah itu lupa'");
    }

    public double getHP(){
        return healthPoint = (level*80)+healthPoint;
    }

    public double getDEF(){
        return defense = (level*10)+defense;
    }

    public double getATKDMG(){
        attackDamage = (level*25)+attackDamage;
        return critOutput(attackDamage);
    }

    @Override
    public double critOutput(double atkdmg) {
        double plusDamage = attackDamage * 0.2;
        return attackDamage + plusDamage;
    }
}

