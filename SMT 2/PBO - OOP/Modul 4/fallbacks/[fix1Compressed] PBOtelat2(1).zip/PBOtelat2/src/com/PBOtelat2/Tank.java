package com.PBOtelat2;

public class Tank extends Character{

    public Tank(int level,String playerN){
        this.level = level;
        checkStatus(playerN,2500,200,750,true,this.level);
    }
    @Override
    public void spawnIntro(){
        System.out.println("'Saya klarifikasi bahwa saya 100% bukan masokis'");
    }

    public double getHP(){
        return healthPoint = (level*150)+healthPoint;
    }

    public double getDEF(){
        return defense = (level*15)+defense;
    }

    public double getATKDMG(){
        return attackDamage = (level*10)+attackDamage;
    }
}
