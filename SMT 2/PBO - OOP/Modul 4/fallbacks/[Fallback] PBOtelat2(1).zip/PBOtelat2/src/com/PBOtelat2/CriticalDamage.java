package com.PBOtelat2;

public interface CriticalDamage {
    double plusDamage = 0.2;
    public void critOutput(double a, double b);
}
