package com.PBOtelat2;

public class Main {
    public static void main(String[] args) {

        System.out.println("==== PLAYER 1 ====");
        System.out.print("level: ");
        Assassin p1 = new Assassin(2);
        p1.name = "Player 1";
        p1.healthPoint=2500;
        p1.defense=200;
        p1.attackDamage=750;
        p1.lifeStatus=true;
        System.out.println("healthPoint : "+p1.getHP());
        System.out.println("defense : "+p1.getDEF());
        System.out.println("attackDamage : "+p1.getATKDMG());

        System.out.println("==== PLAYER 2 ====");
        System.out.print("level: ");
        Tank p2 = new Tank(0);
        p2.name = "Player 2";
        p2.healthPoint=5000;
        p2.defense=400;
        p2.attackDamage=400;
        p2.lifeStatus=true;
        System.out.println("healthPoint : "+p2.getHP());
        System.out.println("defense : "+p2.getDEF());
        System.out.println("attackDamage : "+p2.getATKDMG());

        System.out.println("############ ROUND START ############");
        int i = 1;
        while (p1.lifeStatus && p2.lifeStatus){

            System.out.println("\n\n=== TURN "+i+" ===");
            System.out.println("- Player 1 Move -");
            p1.spawnIntro();
            p1.attack(p2);
            System.out.println("- Player 2 Move -");
            p2.spawnIntro();
            p2.attack(p1);
            i++;

        }





    }
}
