package com.PBOtelat2;

public class Assassin extends Character implements CriticalDamage{

    public Assassin(){}
    public Assassin(int level){
        this.level = level;
        System.out.println(this.level);
    }
    @Override
    public void spawnIntro(){
        System.out.println("saya adalah Assassin");
    }

    @Override
    public void critOutput(double a, double b) {

    }

    public double getHP(){
        return healthPoint = (level*80)+healthPoint;
    }

    public double getDEF(){
        return defense = (level*10)+defense;
    }

    public double getATKDMG(){
        return attackDamage = (level*25)+attackDamage;
    }
}

