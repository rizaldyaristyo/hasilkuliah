package com.PBOtelat2;

public interface CriticalDamage { double critOutput(double atkdmg);}